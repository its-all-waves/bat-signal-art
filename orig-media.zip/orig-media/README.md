Original art by [@kalypsohoman](https://github.com/kalypsohoman)
